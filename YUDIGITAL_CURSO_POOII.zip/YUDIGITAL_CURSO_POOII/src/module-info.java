/**
 * 
 */
/**
 * 
 */
module YUDIGITAL_CURSO_POOII {
	
	requires java.desktop;
	
	requires junit;
	
}