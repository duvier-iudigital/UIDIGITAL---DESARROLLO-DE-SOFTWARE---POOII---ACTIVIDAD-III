package com.compuwork.nucleo;

//IMPORTACIONES-----------------------------

import javax.swing.SwingUtilities;

import com.compuwork.vista.VentanaPrincipal;

public class Main {

	public static void main(String[] args) {
		
		//INTERFAZ GRÁFICA----------------------------------

		SwingUtilities.invokeLater(() -> {
			
			VentanaPrincipal ventana = new VentanaPrincipal();
			
			ventana.setVisible(true);
			
		});
		
	}

}
