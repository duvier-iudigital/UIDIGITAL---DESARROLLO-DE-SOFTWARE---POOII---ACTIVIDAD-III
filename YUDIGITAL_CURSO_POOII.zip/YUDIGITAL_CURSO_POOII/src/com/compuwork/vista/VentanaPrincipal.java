package com.compuwork.vista;

//IMPORTACIONES----------------------------------------------

import javax.swing.JFrame;

import javax.swing.JPanel;

import javax.swing.JTextField;

import javax.swing.SwingUtilities;

import javax.swing.BorderFactory;

import javax.swing.JButton;

import javax.swing.JLabel;

import javax.swing.JOptionPane;

import javax.swing.JComboBox;

import javax.swing.JScrollPane;

import javax.swing.JTextArea;

import javax.swing.DefaultComboBoxModel;

import java.awt.Color;

import java.awt.BorderLayout;

import java.awt.GridLayout;

import java.awt.FlowLayout;

import java.util.ArrayList;

import java.util.List;

import com.compuwork.logica.Departamento;

import com.compuwork.logica.Empleado;

import com.compuwork.logica.EmpleadoPermanente;

import com.compuwork.logica.EmpleadoTemporal;

import com.compuwork.logica.ReporteDesempegno;

public class VentanaPrincipal extends JFrame{
	
	//CAMPOS-----------------------------
	
	private JTextField txtId, txtNombre, txtSueldo, txtMetricas, txtPuntaje;
	
	private JComboBox<String> comboTipo;
	
	private JComboBox<String> comboDeptos;
	
	private JComboBox<Empleado> comboEmpleados;
	
	private DefaultComboBoxModel<String> modeloDeptos;
	
	private DefaultComboBoxModel<Empleado> modeloEmpleados;
	
	private JTextArea areaReporte;
	
	private List<Departamento> listaDeptosLogica;
	
	//CONSTRUCTOR-----------------------------
	
	public VentanaPrincipal () {
		
		setTitle("CompuWork v1.0.1 - Gestión de Personal");
		
		setSize(900, 800);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setLocationRelativeTo(null);
		
		
		listaDeptosLogica = new ArrayList<>();
		
		modeloDeptos = new DefaultComboBoxModel<>();
		
		modeloEmpleados = new DefaultComboBoxModel<>();
		
		
		Departamento inicial = new Departamento("Tecnología");
		
		listaDeptosLogica.add(inicial);
		
		modeloDeptos.addElement(inicial.getNombre());
		
		setLayout(new BorderLayout());
		
		
		JPanel panelForm = new JPanel(new GridLayout(9, 2, 5, 5));
		
		panelForm.setBorder(BorderFactory.createTitledBorder("1. Registro de nuevo empleado(a)"));
		
		
		panelForm.add(new JLabel("ID:"));
		
		txtId = new JTextField();
		
		panelForm.add(txtId);
		
		
		panelForm.add(new JLabel("Nombre:"));
		
		txtNombre = new JTextField();
		
		panelForm.add(txtNombre);
		
		
		panelForm.add(new JLabel("Sueldo base:"));
		
		txtSueldo = new JTextField();
		
		panelForm.add(txtSueldo);
		
		
		panelForm.add(new JLabel("Tipo:"));
		
		comboTipo = new JComboBox<>(new String[] {"Permanente", "Temporal"});
		
		panelForm.add(comboTipo);
		
		
		panelForm.add(new JLabel("Depto inicial:"));
		
		comboDeptos = new JComboBox<>(modeloDeptos);
		
		panelForm.add(comboDeptos);
		
		
		JButton btnNuevoDepto = new JButton("Crear nuevo departamento");
		
		panelForm.add(btnNuevoDepto);
		
		
		panelForm.add(new JLabel("Métricas:"));
		
		txtMetricas = new JTextField();
		
		panelForm.add(txtMetricas);
		
		
		panelForm.add(new JLabel("Puntaje"));
		
		txtPuntaje = new JTextField();
		
		panelForm.add(txtPuntaje);
						
		
		JButton btnRegistrar = new JButton("Registrar empleado(a)");
		
		panelForm.add(btnRegistrar);
		
		
		JPanel panelGestion = new JPanel(new FlowLayout());
		
		panelGestion.setBorder(BorderFactory.createTitledBorder("2. Gestión de empleados registrados"));
		
		
		panelGestion.add(new JLabel("Seleccionar empleado(a)"));
		
		comboEmpleados = new JComboBox<>(modeloEmpleados);
		
		panelGestion.add(comboEmpleados);
		
		
		JButton btnCambiarDepto = new JButton("Cambiar departamento");
		
		JButton btnNuevoReporte = new JButton("Actualizar reporte");
		
		panelGestion.add(btnCambiarDepto);
		
		panelGestion.add(btnNuevoReporte);
		
		
		JPanel panelNorte = new JPanel (new BorderLayout());
		
		panelNorte.add(panelForm, BorderLayout.NORTH);
		
		panelNorte.add(panelGestion, BorderLayout.SOUTH);
		
		add(panelNorte, BorderLayout.NORTH);
		
		
		areaReporte = new JTextArea();
		
		areaReporte.setEditable(false);
		
		areaReporte.setBackground(new Color(245, 245, 245));
		
		add( new JScrollPane(areaReporte), BorderLayout.CENTER);
		
		
		btnNuevoDepto.addActionListener(e ->{
			
			String nombre = JOptionPane.showInputDialog(this, "Nombre del nuevo departamento");
			
			if(nombre != null && !nombre.trim().isEmpty()) {
				
				listaDeptosLogica.add(new Departamento(nombre));
				
				modeloDeptos.addElement(nombre);
				
			}
			
		});
		
		
		btnRegistrar.addActionListener(e -> procesarNuevoRegistro());
		
		
		btnCambiarDepto.addActionListener(e -> {
			
			Empleado seleccionado = (Empleado) comboEmpleados.getSelectedItem();
			
			if(seleccionado == null) {
				
				JOptionPane.showMessageDialog(this, "Primero seleccione un empleado/empleada de la lista");
				
				return;
												
			}
			
			int tamagno  = modeloDeptos.getSize();
			
			String[] opcionesDeptos = new String[tamagno];
			
			for (int i = 0; i < tamagno; i ++) {
				
				opcionesDeptos[i] = modeloDeptos.getElementAt(i);
				
			}
			
			String nuevoDeptoNombre = (String) JOptionPane.showInputDialog(this, "Seleccione el nuevo departamento para " + seleccionado.getNombre(), "Cambio de departamento",
					JOptionPane.QUESTION_MESSAGE, null, opcionesDeptos, modeloDeptos.getElementAt(0));
			
			if(nuevoDeptoNombre != null) {
				
				seleccionado.setDepartamento(nuevoDeptoNombre);
				
				areaReporte.append("\n[SISTEMA] " + seleccionado.getNombre() + " movido/movida a " + nuevoDeptoNombre + "\n");
				
			}
			
		});
		

		btnNuevoReporte.addActionListener(e -> {
			
			Empleado seleccionado = (Empleado) comboEmpleados.getSelectedItem();
			
			if(seleccionado == null) {
				
				JOptionPane.showMessageDialog(this, "Primero seleccione un empleado/empleada de la lista");
				
				return;
				
			}
			
			try {
				
				String m = JOptionPane.showInputDialog(this, "Nuevas métricas:");
				
				String pStr = JOptionPane.showInputDialog(this, "Nuevo puntaje (0-100):");
				
				if (m != null && pStr != null) {
					
					double p = Double.parseDouble(pStr);
					
					ReporteDesempegno nuevoRep = new ReporteDesempegno(seleccionado, m, p);
					
					areaReporte.append("\n" + nuevoRep.generarReporte() + "\n");
					
				}
				
			} catch (Exception ex) {
				
				JOptionPane.showMessageDialog(this, "Error de datos: " + ex.getMessage());
				
			}
			
		});
				
	}
	
	//MÉTODOS-------------------------------------
	
	private void procesarNuevoRegistro() {
		
		try {
			
			int id = Integer.parseInt(txtId.getText());
			
			String nombre = txtNombre.getText();
			
			int sueldo = Integer.parseInt(txtSueldo.getText());
			
			double puntaje = Double.parseDouble(txtPuntaje.getText());
			
			
			Empleado nuevo;
			
			if(comboTipo.getSelectedItem().equals("Permanente")) {
				
				nuevo = new EmpleadoPermanente(id, nombre, sueldo, 150000);
				
			} else {
				
				nuevo = new EmpleadoTemporal(id, nombre, sueldo, 31, 12, 2026);
				
			}
			
			int index = comboDeptos.getSelectedIndex();
			
			listaDeptosLogica.get(index).assignarEmpleado(nuevo);
			
			
			ReporteDesempegno rep = new ReporteDesempegno(nuevo, txtMetricas.getText(), puntaje);
			
			
			modeloEmpleados.addElement(nuevo);
			
			
			areaReporte.append("\n" + rep.generarReporte() + "\n");
			
			limpiarCampos();
			
			JOptionPane.showMessageDialog(this, "Empelado/empleada registrado y añadido a la lista de gestión");
						
		} catch (Exception ex) {
			
			JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
			
		}
	}
	
	private void limpiarCampos() {
		
		txtId.setText("");
		
		txtNombre.setText("");
		
		txtSueldo.setText("");
		
		txtMetricas.setText("");
		
		txtPuntaje.setText("");
				
	}
	
}
