package com.compuwork.pruebas;

//IMPORTACIONES------------------------------------

import static org.junit.Assert.*;

import org.junit.Test;

import com.compuwork.logica.*;

public class CompuWorkPrueba {
	
	//PRUEBAS--------------------------------------

	@Test
	public void testSueldoPermanente() {
		
		EmpleadoPermanente emp = new EmpleadoPermanente(1, "prueba", 1000, 500);
		
		emp.calcularSalario();
		
		assertEquals(1500, emp.getSalario());
		
	}
	
	
	@Test(expected = Exception.class)
	
	public void testEscepcionEmpleadoNulo() throws Exception{
		
		Departamento depto = new Departamento("Pruebas");
		
		depto.assignarEmpleado(null);
		
	}
	
}
